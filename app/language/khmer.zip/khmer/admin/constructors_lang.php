<?php defined('BASEPATH') OR exit('No direct script access allowed');
/*
 * Module: Costructions
 * Language: English
 *
 * Last edited:
 * 30th April 2015
 *
 *
 * You can translate this file to your language.
 * For instruction on new language setup, please visit the documentations.
 * You also can share your language files by emailing to icloud.erp@gmail.com
 * Thank you
 */
$lang['constructor_cannot_delete']				= "Constructor Cannot Delete";
$lang['constructor_deleted']     				= "Constructor has been successfully deleted";  
$lang['constructors_deleted']     				= "Constructors has been successfully deleted";  
$lang['constructor_edited']     				= "Constructor has been successfully edited";  
$lang['constructor_added']     					= "Constructor has been successfully added";  
$lang['edit_constructor']						= "Edit Constructor";
$lang['delete_constructor']						= "Delete Constructor";
$lang['delete_constructors']					= "Delete Constructors";
$lang['add_constructor']						= "Add Constructor"; 
$lang['constructors']							= "Constructors";
$lang['constructor']							= "Constructor";
$lang['constructions']							= "Constructions";
$lang['construction']							= "Construction";   


      
 ?>